package com.bank.CustomerRepository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bank.entity.*;

public interface CustomerRepository extends JpaRepository<CustomerEntity, Long>{

}