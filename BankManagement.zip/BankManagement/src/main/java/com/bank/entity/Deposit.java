package com.bank.entity;

import javax.persistence.Column;
import javax.persistence.Table;


@Table(name = "customer")
public class Deposit {
    public long getDeposit() {
        return deposit;
    }
    public void setDeposit(long deposit) {
        this.deposit = deposit;
    }
    @Column(name = "deposit")
    private long deposit;
    public Deposit() {
        this.deposit = deposit;
    }
}

