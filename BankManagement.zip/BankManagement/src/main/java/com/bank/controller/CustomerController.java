package com.bank.controller;

import com.bank.entity.Deposit;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.bank.entity.CustomerEntity;
import com.bank.service.CustomerService;

@Controller
public class CustomerController {
	
	private CustomerService customerService;

	public CustomerController(CustomerService customerService) {
		super();
		this.customerService = customerService;
	}
	
	
	@GetMapping("/customer")
	public String listCustomers(Model model) {
		model.addAttribute("customer", customerService.getAllCustomers());
		return "customer";
	}
	
	@GetMapping("/customer/new")
	public String createCustomerForm(Model model) {
		CustomerEntity customers = new CustomerEntity();
		model.addAttribute("customer", customers);
		return "CustomerAdd";
		
	}
	
	@PostMapping("/customer")
	public String saveCustomer(@ModelAttribute("customer") CustomerEntity customers) {
		customerService.saveCustomer(customers);
		return "redirect:/customer";
	}
	
	@GetMapping("/customer/edit/{id}")
	public String editCustomerForm(@PathVariable Long id, Model model) {
		model.addAttribute("customer", customerService.getCustomerById(id));
		return "UpdateCustomer";
	}

	@PostMapping("/customer/{id}")
	public String updateCustomer(@PathVariable Long id,
			@ModelAttribute("customer") CustomerEntity customer,
			Model model) {
		
		// get student from database by id
		CustomerEntity cust = customerService.getCustomerById(id);
		cust.setId(id);
		cust.setFirstName(cust.getFirstName());
		cust.setLastName(cust.getLastName());
		cust.setEmail(cust.getEmail());
		cust.setPassword(cust.getPassword());
		cust.setAmount(cust.getAmount());
		
		// save updated student object
		customerService.updateCustomer(cust);
		return "redirect:/customer";
	}
	
	// handler method to handle delete student request
	
	@GetMapping("/customer/{id}")
	public String deleteStudent(@PathVariable Long id) {
		customerService.deleteCustomerById(id);
		return "redirect:/customer";
	}

	@GetMapping("/customer/deposit/{id}")
	public String addDeposit(@PathVariable Long id, Model model){
		model.addAttribute("customer",customerService.depositCustomerById(id));
		return "deposit";
	}
	@PostMapping("/customer/deposit/{id}")
	public String getDeposit(@PathVariable Long id, @ModelAttribute("customer") CustomerEntity cust,Model model){
		CustomerEntity customer = customerService.depositCustomerById(id);
		Deposit deposit=new Deposit();
		deposit.setDeposit(deposit.getDeposit());
		customer.setAmount(customer.getAmount());
		customerService.saveCustomer(customer);
		customerService.getCustomerById(id);
		return "redirect:/customer";
	}
	
}
