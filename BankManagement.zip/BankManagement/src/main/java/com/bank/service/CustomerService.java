package com.bank.service;

import java.util.List;

import com.bank.entity.CustomerEntity;

public interface CustomerService {
	List<CustomerEntity> getAllCustomers();
	
	CustomerEntity saveCustomer(CustomerEntity customer);
	
	CustomerEntity getCustomerById(Long id);
	
	CustomerEntity updateCustomer(CustomerEntity customer);
	
	void deleteCustomerById(Long id);

	CustomerEntity depositCustomerById(Long id);
}